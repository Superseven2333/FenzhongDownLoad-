import tkinter as tk
from tkinter import *
import requests,_thread
import time,os
import zipfile



window = tk.Tk()
window.geometry("640x600")
window.resizable(0,0)
window.title("FenzhongDownLoad(适用于装机/进入系统后 的软件安装)")
window.iconbitmap('ico.ico')
list = []
def sd():
    list.append('360sd')
sd0 = tk.Checkbutton(window,text = "360杀毒",command=sd).grid()
def hur():
    list.append("hr")
hr = tk.Checkbutton(window,text = "火绒安全",command=hur)
hr.place(x=213,y=0)
def zla():
    list.append("zl")
zl = tk.Checkbutton(window,text = "智量终端安全",command=zla)
zl.place(x=426,y=0)
def zip():
    list.append("zip")
zip1 = tk.Checkbutton(window,text = "360Zip国际版",command=zip)
zip1.place(x=0,y=20)
def frx():
    list.append("fx")
fx = tk.Checkbutton(window,text = "FireFox",command=frx)
fx.place(x=0,y=40)
def opr():
    list.append("op")
op = tk.Checkbutton(window,text = "Opera",command=opr)
op.place(x=213,y=40)
def mm():
    list.append("tm")
tim = tk.Checkbutton(window,text = "TIM",command=mm)
tim.place(x=0,y=60)
def w1():
    list.append("wx")
wxx = tk.Checkbutton(window,text = "微信",command=w1)
wxx.place(x=213,y=60)
def ds():
    list.append("ds")
dis = tk.Checkbutton(window,text = "Dism++",command=ds)
dis.place(x=0,y=80)
def bn():
    print(list)
    if "360sd" in list:
        sd = "https://down.360safe.com/360sd/360sd_x64_std_7.0.0.1001E.exe"
        sd1 = requests.get(sd,stream = True)
        open("sd.exe","wb").write(sd1.content)
    if "hr" in list:
        hr = "https://huorong.cn/downloadfullv5.html?status=hrstat&src=18"
        hr1 = requests.get(hr,stream = True)
        open("hr.exe","wb").write(hr1.content)
    if "zl" in list:
        zl = "https://www.wisevector.com/WiseVector_Setup.exe"
        zl1 = requests.get(zl,stream = True)
        open("zl.exe","wb").write(zl1.content)
    if "zip" in list:
        zp = "https://free.360totalsecurity.com/360zip/360zip_setup_1.0.0.1041.exe"
        zp1 = requests.get(zp,stream = True)
        open("zip.exe","wb").write(zp1.content)
    if "fx" in list:
        fx = "https://download-ssl.firefox.com.cn/releases-sha2/stub/official/zh-CN/Firefox-latest.exe"
        fx1 = requests.get(fx,stream = True)
        open("fx.exe","wb").write(fx1.content)
    if "op" in list:
        op = "https://download.operachina.com/pub/opera/desktop/78.0.4093.184/win/Opera_78.0.4093.184_Setup.exe"
        op1 = requests.get(op,stream = True)
        open("op.exe","wb").write(op1.content)
    if "tm" in list:
        tm = "https://dldir1.qq.com/qqfile/qq/PCTIM/TIM3.3.8/TIM3.3.8.22043.exe"
        tm1 = requests.get(tm,stream = True)
        open("tm.exe","wb").write(tm1.content)
    if "wx" in list:
        wx = "https://dldir1.qq.com/weixin/Windows/WeChatSetup.exe"
        wx1 = requests.get(wx,stream = True)
        open("wx.exe","wb").write(wx1.content)
    if "ds" in list:
        dm = "http://gh.api.99988866.xyz/github.com/Chuyu-Team/Dism-Multi-language/releases/download/v10.1.1002.1/Dism++10.1.1002.1.zip"
        dm1 = requests.get(dm,stream = True)
        open("dm.zip","wb").write(dm1.content)
    zip_file = zipfile.ZipFile('dm.zip')
    # 解压
    zip_extract = zip_file.extractall("./")
    zip_extract.close()
    os.system("Dism++x86.exe")
    os.system("zl.exe")
    os.system("zip.exe")
    os.system("hr.exe")
    os.system("fx.exe")
    os.system("sd.exe")
    os.system("op.exe")
    os.system("wx.exe")
    os.system("tm.exe")
    time.sleep(10)
btn = tk.Button(window,width=15,height=3,text="提交！",command=bn)
def d():
    time.sleep(2)
    if "360sd" in list:
        os.remove("sd.exe")
    if "hr" in list:
          os.remove("hr.exe")
    if "zl" in list:
        os.remove("zl.exe")
       
    if "zip" in list:
        os.remove("zip.exe")
    if "fx" in list:
       os.remove("fx.exe")
    if "op" in list:
        os.remove("op.exe")
    if "tm" in list:
       os.remove("tm.exe")
    if "wx" in list:
        os.remove("wx.exe")
    if "ds" in list:
        os.remove("dm.zip")
    os.remove("FenzhongDowload.exe")
    
    
   
def dn():
    list.clear()
    
btn2 = tk.Button(window,width=15,height=2,text="我搞错了！",command=dn)
btn2.place(x=213,y=219)
btn1 = tk.Button(window,width=15,height=2,text="安装完成,开始卸载",command=d)
btn.place(x=213,y=120)
btn1.place(x=213,y=178)
window.mainloop()